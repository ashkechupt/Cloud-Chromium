#!/bin/bash
set -e

# Trap to clean up on exit
trap 'echo "Script terminated at $(date)" >> /tmp/watchdog.log; kill 0' EXIT HUP INT TERM

echo "[$(date)] Starting Replit Chromium Desktop..."

# ============================================================================
# 1. BASE SETUP
# ============================================================================
echo "[$(date)] Step 1: Base setup..."
apt-get update -qq
apt-get install -y -qq xvfb fluxbox x11vnc novnc chromium-browser curl xdotool > /dev/null 2>&1

# Create Chromium policies directory and file
mkdir -p /etc/chromium/policies/managed
cat > /etc/chromium/policies/managed/policies.json << 'EOF'
{"ExtensionInstallAllowlist": ["*"]}
EOF

# Initialize logs
> /tmp/watchdog.log
> /tmp/tunnel.log

echo "[$(date)] Base setup complete"

# ============================================================================
# 2. VIRTUAL DISPLAY & DESKTOP
# ============================================================================
echo "[$(date)] Step 2: Starting virtual display..."
Xvfb :1 -screen 0 1024x768x8 > /dev/null 2>&1 &
XVFB_PID=$!
sleep 2

# Set display for all subsequent commands
export DISPLAY=:1

# Disable mouse acceleration
xset m 0 0

# Start Fluxbox
fluxbox > /dev/null 2>&1 &
sleep 2
fluxbox-remote "SetStyle: Clean" > /dev/null 2>&1

echo "[$(date)] Virtual display ready"

# ============================================================================
# 3. FLUXBOX STARTUP SCRIPT WITH CHROMIUM AUTO-START
# ============================================================================
echo "[$(date)] Step 3: Setting up Fluxbox startup..."
mkdir -p ~/.fluxbox
cat > ~/.fluxbox/startup << 'STARTUP'
#!/bin/bash
# Fluxbox startup script
exec dbus-launch --exit-with-session fluxbox

# Launch Chromium in the background
chromium-browser --no-sandbox --disable-gpu --start-fullscreen \
  --no-first-run --disable-default-apps \
  --user-data-dir=$HOME/.chromium \
  --enable-smooth-scrolling \
  --window-size=1024,768 > /dev/null 2>&1 &
STARTUP
chmod +x ~/.fluxbox/startup

# Manual Chromium startup (fallback after 5 seconds)
(
  sleep 5
  chromium-browser --no-sandbox --disable-gpu --start-fullscreen \
    --no-first-run --disable-default-apps \
    --user-data-dir=$HOME/.chromium \
    --enable-smooth-scrolling \
    --window-size=1024,768 > /dev/null 2>&1 &
) &

echo "[$(date)] Chromium auto-start configured"

# ============================================================================
# 4. X11VNC – ULTRA-LOW BANDWIDTH
# ============================================================================
echo "[$(date)] Step 4: Starting x11vnc..."
# Kill any leftover instances
pkill -f "x11vnc" || true
sleep 1

x11vnc -display :1 -forever -nopw -rfbport 5900 -bg \
  -shared -repeat \
  -jpeg -quality 30 -fps 3 \
  -wait 5 -defer 5 -nomodtweak -noxdamage -noxfixes \
  > /dev/null 2>&1 &

# Verify port 5900 is listening
for i in {1..10}; do
  if netstat -tuln 2>/dev/null | grep -q ':5900' || nc -z localhost 5900 2>/dev/null; then
    echo "[$(date)] x11vnc listening on port 5900"
    break
  fi
  if [ $i -eq 10 ]; then
    echo "[ERROR] x11vnc failed to bind on port 5900"
    exit 1
  fi
  sleep 1
done

# ============================================================================
# 5. NOVNC
# ============================================================================
echo "[$(date)] Step 5: Starting noVNC..."
novnc --listen 6080 --vnc localhost:5900 > /dev/null 2>&1 &
NOVNC_PID=$!

# Verify port 6080 is listening
for i in {1..10}; do
  if netstat -tuln 2>/dev/null | grep -q ':6080' || nc -z localhost 6080 2>/dev/null; then
    echo "[$(date)] noVNC listening on port 6080"
    break
  fi
  if [ $i -eq 10 ]; then
    echo "[ERROR] noVNC failed to bind on port 6080"
    exit 1
  fi
  sleep 1
done

# ============================================================================
# 6. TUNNEL – LOCALHOST.RUN (SSH, NO CLOUDFLARE)
# ============================================================================
echo "[$(date)] Step 6: Starting SSH tunnel..."
pkill -f "localhost.run" || true
sleep 1

# Immortal tunnel loop
(
  while true; do
    ssh -o StrictHostKeyChecking=no -o ServerAliveInterval=30 \
      -R 80:localhost:6080 nokey@localhost.run \
      >> /tmp/tunnel.log 2>&1 &
    TUNNEL_PID=$!
    sleep 30
    if ! kill -0 $TUNNEL_PID 2>/dev/null; then
      sleep 3
    fi
  done
) &
TUNNEL_LOOP_PID=$!

# Wait for tunnel to establish and extract URL
echo "[$(date)] Waiting for tunnel URL..."
TUNNEL_URL=""
for i in {1..20}; do
  sleep 1
  TUNNEL_URL=$(grep -o 'https://[^ ]*\.lhr\.life' /tmp/tunnel.log | tail -1)
  if [ -n "$TUNNEL_URL" ]; then
    echo "$TUNNEL_URL" > /tmp/tunnel_url.txt
    echo "[$(date)] Tunnel established: $TUNNEL_URL"
    break
  fi
done

if [ -z "$TUNNEL_URL" ]; then
  echo "[ERROR] Failed to establish tunnel URL within timeout"
  exit 1
fi

# ============================================================================
# 7. LIVE PREVIEW PANE (PORT 9090)
# ============================================================================
echo "[$(date)] Step 7: Starting live preview server..."

cat > /tmp/preview_server.py << 'PYTHON'
#!/usr/bin/env python3
import http.server
import socketserver
import os
from datetime import datetime
import time

PORT = 9090

class PreviewHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/' or self.path == '':
            self.send_response(200)
            self.send_header('Content-type', 'text/html; charset=utf-8')
            self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
            self.end_headers()
            
            tunnel_url = ""
            tunnel_file = "/tmp/tunnel_url.txt"
            
            if os.path.exists(tunnel_file):
                try:
                    with open(tunnel_file, 'r') as f:
                        tunnel_url = f.read().strip()
                except:
                    pass
            
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            if tunnel_url:
                # Construct noVNC URL with compression parameters
                novnc_url = f"{tunnel_url}?quality=2&compression=9&autoconnect=true&reconnect=true&resize=scale"
                html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Replit Chromium Desktop</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {{
            margin: 0;
            padding: 0;
            background: #1a1a1a;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        }}
        #container {{
            width: 100vw;
            height: 100vh;
            display: flex;
            flex-direction: column;
        }}
        #novnc {{
            flex: 1;
            border: none;
        }}
        #footer {{
            background: #0a0a0a;
            color: #888;
            padding: 10px 15px;
            font-size: 12px;
            border-top: 1px solid #333;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}
        #tunnel-info {{
            word-break: break-all;
            max-width: 70%;
        }}
        .status {{
            color: #4a9eff;
        }}
    </style>
</head>
<body>
    <div id="container">
        <iframe id="novnc" src="{novnc_url}"></iframe>
        <div id="footer">
            <div id="tunnel-info">
                <span class="status">✓ Tunnel:</span> {tunnel_url}
            </div>
            <div id="timestamp">{timestamp}</div>
        </div>
    </div>
</body>
</html>"""
            else:
                html = """<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Replit Chromium Desktop</title>
    <meta http-equiv="refresh" content="5">
    <style>
        body {
            margin: 0;
            padding: 0;
            background: #1a1a1a;
            color: #ccc;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .message {
            text-align: center;
            padding: 20px;
        }
        .spinner {
            border: 4px solid #333;
            border-top: 4px solid #4a9eff;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="message">
        <div class="spinner"></div>
        <h1>Tunnel is restarting…</h1>
        <p>Refreshing in 5 seconds</p>
    </div>
</body>
</html>"""
            
            self.wfile.write(html.encode('utf-8'))
        else:
            self.send_response(404)
            self.end_headers()
    
    def log_message(self, format, *args):
        pass  # Suppress logging

try:
    with socketserver.TCPServer(("", PORT), PreviewHandler) as httpd:
        print(f"Preview server running on port {PORT}", flush=True)
        httpd.serve_forever()
except Exception as e:
    print(f"Preview server error: {e}", flush=True)
PYTHON

chmod +x /tmp/preview_server.py
python3 /tmp/preview_server.py > /dev/null 2>&1 &
PREVIEW_PID=$!

# Verify preview server is listening
for i in {1..10}; do
  if netstat -tuln 2>/dev/null | grep -q ':9090' || nc -z localhost 9090 2>/dev/null; then
    echo "[$(date)] Preview server listening on port 9090"
    break
  fi
  if [ $i -eq 10 ]; then
    echo "[ERROR] Preview server failed to start"
    exit 1
  fi
  sleep 1
done

# ============================================================================
# 8. SELF-HEALING WATCHDOG
# ============================================================================
echo "[$(date)] Step 8: Starting watchdog..."

cat > /tmp/watchdog.sh << 'WATCHDOG'
#!/bin/bash

WATCHDOG_LOG="/tmp/watchdog.log"
DISPLAY=:1
export DISPLAY

check_and_restart() {
  local component=$1
  local check_cmd=$2
  local restart_cmd=$3
  
  if ! eval "$check_cmd" > /dev/null 2>&1; then
    echo "[$(date)] [$component] DEAD - restarting..." >> $WATCHDOG_LOG
    eval "$restart_cmd" > /dev/null 2>&1 &
    sleep 2
    
    # Special handling for SSH tunnel
    if [ "$component" = "SSH Tunnel" ]; then
      sleep 13
      TUNNEL_URL=$(grep -o 'https://[^ ]*\.lhr\.life' /tmp/tunnel.log 2>/dev/null | tail -1)
      if [ -n "$TUNNEL_URL" ]; then
        echo "$TUNNEL_URL" > /tmp/tunnel_url.txt
        echo "[$(date)] [SSH Tunnel] New URL: $TUNNEL_URL" >> $WATCHDOG_LOG
      fi
    fi
  fi
}

# Watchdog loop
while true; do
  sleep 5
  
  # Check Xvfb
  check_and_restart "Xvfb" \
    "pgrep Xvfb" \
    "Xvfb :1 -screen 0 1024x768x8"
  
  # Check Fluxbox
  check_and_restart "Fluxbox" \
    "pgrep fluxbox" \
    "fluxbox"
  
  # Check x11vnc
  check_and_restart "x11vnc" \
    "netstat -tuln 2>/dev/null | grep -q ':5900' || nc -z localhost 5900 2>/dev/null" \
    "x11vnc -display :1 -forever -nopw -rfbport 5900 -bg -shared -repeat -jpeg -quality 30 -fps 3 -wait 5 -defer 5 -nomodtweak -noxdamage -noxfixes"
  
  # Check noVNC
  check_and_restart "noVNC" \
    "netstat -tuln 2>/dev/null | grep -q ':6080' || nc -z localhost 6080 2>/dev/null" \
    "novnc --listen 6080 --vnc localhost:5900"
  
  # Check Chromium
  check_and_restart "Chromium" \
    "pgrep chromium" \
    "DISPLAY=:1 chromium-browser --no-sandbox --disable-gpu --start-fullscreen --no-first-run --disable-default-apps --user-data-dir=/home/runner/.chromium --enable-smooth-scrolling --window-size=1024,768"
  
  # Check SSH tunnel
  check_and_restart "SSH Tunnel" \
    "pgrep -f 'localhost.run'" \
    "ssh -o StrictHostKeyChecking=no -o ServerAliveInterval=30 -R 80:localhost:6080 nokey@localhost.run >> /tmp/tunnel.log 2>&1"
done
WATCHDOG

chmod +x /tmp/watchdog.sh
/tmp/watchdog.sh > /dev/null 2>&1 &
WATCHDOG_PID=$!

echo "[$(date)] Watchdog started"

# ============================================================================
# 9. FINAL STARTUP VERIFICATION
# ============================================================================
echo "[$(date)] Step 9: Final startup verification..."

verify_component() {
  local name=$1
  local check=$2
  local retries=3
  
  for i in $(seq 1 $retries); do
    if eval "$check" > /dev/null 2>&1; then
      echo "[$(date)] ✓ $name verified"
      return 0
    fi
    if [ $i -lt $retries ]; then
      echo "[$(date)] $name check failed, retry $i/$retries..."
      sleep 10
    fi
  done
  
  echo "[ERROR] $name verification failed after $retries retries"
  return 1
}

verify_component "Xvfb" "pgrep Xvfb"
verify_component "Fluxbox" "pgrep fluxbox"
verify_component "x11vnc (port 5900)" "netstat -tuln 2>/dev/null | grep -q ':5900' || nc -z localhost 5900 2>/dev/null"
verify_component "noVNC (port 6080)" "netstat -tuln 2>/dev/null | grep -q ':6080' || nc -z localhost 6080 2>/dev/null"
verify_component "Chromium" "pgrep chromium"
verify_component "SSH Tunnel" "pgrep -f 'localhost.run'"
verify_component "Preview Server (port 9090)" "netstat -tuln 2>/dev/null | grep -q ':9090' || nc -z localhost 9090 2>/dev/null"

echo ""
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║                   ALL SYSTEMS READY                           ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

TUNNEL_URL=$(cat /tmp/tunnel_url.txt 2>/dev/null)
if [ -n "$TUNNEL_URL" ]; then
  echo "📱 Remote Desktop URL: $TUNNEL_URL"
  echo "🌐 Live Preview:       http://localhost:9090"
  echo ""
  echo "Components:"
  echo "  ✓ Xvfb (Virtual Display)"
  echo "  ✓ Fluxbox (Desktop)"
  echo "  ✓ Chromium (Browser)"
  echo "  ✓ x11vnc (VNC Server)"
  echo "  ✓ noVNC (Web Interface)"
  echo "  ✓ SSH Tunnel (localhost.run)"
  echo "  ✓ Watchdog (Self-Healing)"
  echo ""
fi

echo "[$(date)] Startup complete" >> /tmp/watchdog.log

# ============================================================================
# 10. KEEPALIVE & CRASH RECOVERY
# ============================================================================
# Stay alive forever
while true; do
  sleep 60
done
