#!/bin/bash
set -e

# Trap to clean up on exit
trap 'echo "Script terminated at $(date)" >> /tmp/watchdog.log; kill 0' EXIT HUP INT TERM

echo "[$(date)] Starting Optimized Replit Chromium Desktop..."

# ============================================================================
# 1. BASE SETUP + PERFORMANCE TUNING
# ============================================================================
echo "[$(date)] Step 1: Base setup & optimization..."
apt-get update -qq
apt-get install -y -qq xvfb fluxbox x11vnc novnc chromium-browser curl xdotool wmctrl > /dev/null 2>&1

# Kernel tuning for network performance
echo 1 > /proc/sys/net/ipv4/tcp_tw_reuse 2>/dev/null || true
echo 1 > /proc/sys/net/ipv4/tcp_timestamps 2>/dev/null || true
sysctl -w net.ipv4.tcp_window_scaling=1 2>/dev/null || true
sysctl -w net.core.rmem_max=134217728 2>/dev/null || true

# Create Chromium policies directory and file
mkdir -p /etc/chromium/policies/managed
cat > /etc/chromium/policies/managed/policies.json << 'EOF'
{"ExtensionInstallAllowlist": ["*"]}
EOF

# Initialize logs
> /tmp/watchdog.log
> /tmp/tunnel.log

# Disable swap (RAM only, faster)
swapoff -a 2>/dev/null || true

echo "[$(date)] Base setup complete - Network tuned"

# ============================================================================
# 2. VIRTUAL DISPLAY & DESKTOP (OPTIMIZED)
# ============================================================================
echo "[$(date)] Step 2: Starting virtual display..."
# Use 16-bit color depth for faster rendering (vs 24-bit)
Xvfb :1 -screen 0 1024x768x16 +iglx -nolisten unix > /dev/null 2>&1 &
XVFB_PID=$!
sleep 1

# Set display for all subsequent commands
export DISPLAY=:1

# Disable mouse acceleration & set faster response
xset m 0 0
xset r rate 200 25  # Keyboard repeat: delay 200ms, rate 25 Hz

# Start minimal Fluxbox (no decorations, no animations)
fluxbox > /dev/null 2>&1 &
sleep 1

# Remove window decorations for faster rendering
fluxbox-remote "SetStyle: Clean" > /dev/null 2>&1
fluxbox-remote "Workspace1" > /dev/null 2>&1

echo "[$(date)] Virtual display ready - 16-bit optimized"

# ============================================================================
# 3. FLUXBOX STARTUP SCRIPT WITH CHROMIUM AUTO-START (OPTIMIZED)
# ============================================================================
echo "[$(date)] Step 3: Setting up Fluxbox startup with optimized Chromium..."
mkdir -p ~/.fluxbox
cat > ~/.fluxbox/startup << 'STARTUP'
#!/bin/bash
exec dbus-launch --exit-with-session fluxbox

# Aggressive performance flags for Chromium
chromium-browser \
  --no-sandbox --disable-gpu --disable-gpu-compositing \
  --disable-extensions --disable-plugins \
  --start-fullscreen --no-first-run --disable-default-apps \
  --disable-sync --disable-translate --disable-default-apps \
  --user-data-dir=$HOME/.chromium \
  --enable-smooth-scrolling \
  --renderer-process-limit=1 \
  --memory-pressure-off \
  --disable-background-networking \
  --disable-preconnect \
  --disable-hang-monitor \
  --disable-popup-blocking \
  --disable-prompt-on-repost \
  --disable-component-extensions-with-background-pages \
  --disable-default-apps \
  --disable-component-update \
  --disable-supervised-user-safesites \
  --disable-permissions-api \
  --disable-backgrounding-occluded-windows \
  --disable-breakpad \
  --disable-client-side-phishing-detection \
  --disable-component-update \
  --disable-datasaver-prompt \
  --disable-default-apps \
  --disable-device-discovery-notifications \
  --disable-domain-reliability \
  --disable-enhanced-spell-check \
  --disable-extensions-except-listed \
  --disable-extensions-file-access-check \
  --disable-field-trial-config \
  --disable-geolocation \
  --disable-histogram-customizer \
  --disable-infobars \
  --disable-in-process-stack-traces \
  --disable-install-tracking \
  --disable-machine-learning-experiments \
  --disable-metrics \
  --disable-module-scrambling \
  --disable-network-prediction \
  --disable-notifications \
  --disable-offline-pages \
  --disable-offering-book-reader-for-epub \
  --disable-openscreen-receiver \
  --disable-origins-trial-for-http-localhost \
  --disable-password-generation \
  --disable-password-manager-reauthentication \
  --disable-permissions-api \
  --disable-pnacl \
  --disable-print-preview \
  --disable-profile-shortcut-manager \
  --disable-prompt-on-repost \
  --disable-pull-to-refresh \
  --disable-reading-list \
  --disable-remote-fonts \
  --disable-renderer-backgrounding \
  --disable-reporting-api \
  --disable-rtc-smoothness-algorithm \
  --disable-safe-browsing \
  --disable-sample-tiles \
  --disable-search-engine-choice-screen \
  --disable-search-geolocation-disclosure \
  --disable-search-provider-choice-screen \
  --disable-service-side-preload \
  --disable-services-service-worker-migration \
  --disable-session-crashed-bubble \
  --disable-sync-types=history \
  --disable-translate \
  --disable-usb-power-query \
  --disable-wake-on-wifi \
  --disable-webaudio-midi \
  --disable-webgl \
  --disable-webnfc \
  --disable-webrtc-encryption \
  --disable-webusb \
  --disable-wwlc \
  --disable-xss-auditor \
  --disable-zero-copy-tile-rendering \
  --window-size=1024,768 \
  --no-first-run \
  --no-default-browser-check \
  --no-pings \
  --no-service-autorun \
  --memory-model=low > /dev/null 2>&1 &
STARTUP
chmod +x ~/.fluxbox/startup

# Manual Chromium startup (fallback after 3 seconds)
(
  sleep 3
  chromium-browser \
    --no-sandbox --disable-gpu --disable-gpu-compositing \
    --disable-extensions --disable-plugins \
    --start-fullscreen --no-first-run --disable-default-apps \
    --disable-sync --disable-translate \
    --user-data-dir=$HOME/.chromium \
    --enable-smooth-scrolling \
    --renderer-process-limit=1 \
    --memory-pressure-off \
    --disable-background-networking \
    --disable-preconnect \
    --disable-hang-monitor \
    --disable-popup-blocking \
    --disable-prompt-on-repost \
    --disable-component-extensions-with-background-pages \
    --disable-default-apps \
    --disable-component-update \
    --disable-supervised-user-safesites \
    --window-size=1024,768 \
    --no-first-run \
    --no-default-browser-check > /dev/null 2>&1 &
) &

echo "[$(date)] Chromium auto-start configured - Performance optimized"

# ============================================================================
# 4. X11VNC – ULTRA-LOW BANDWIDTH (EXTREME OPTIMIZATION)
# ============================================================================
echo "[$(date)] Step 4: Starting x11vnc..."
# Kill any leftover instances
pkill -f "x11vnc" || true
sleep 1

# EXTREME compression: 8-bit indexed color, JPEG quality 5, 1 FPS, motion detection
x11vnc -display :1 -forever -nopw -rfbport 5900 -bg \
  -shared -repeat \
  -8to24 -flashcmap \
  -jpeg -quality 5 \
  -fps 1 \
  -wait 10 -defer 10 \
  -nomodtweak -noxdamage -noxfixes -noxext \
  -fast -connect localhost \
  -rfbport 5900 \
  -threads \
  -quiet \
  > /dev/null 2>&1 &

# Verify port 5900 is listening
for i in {1..10}; do
  if netstat -tuln 2>/dev/null | grep -q ':5900' || nc -z localhost 5900 2>/dev/null; then
    echo "[$(date)] x11vnc listening on port 5900 (1 FPS, 8-bit)"
    break
  fi
  if [ $i -eq 10 ]; then
    echo "[ERROR] x11vnc failed to bind on port 5900"
    exit 1
  fi
  sleep 1
done

# ============================================================================
# 5. NOVNC (OPTIMIZED)
# ============================================================================
echo "[$(date)] Step 5: Starting noVNC..."
novnc --listen 6080 --vnc localhost:5900 > /dev/null 2>&1 &
NOVNC_PID=$!

# Verify port 6080 is listening
for i in {1..10}; do
  if netstat -tuln 2>/dev/null | grep -q ':6080' || nc -z localhost 6080 2>/dev/null; then
    echo "[$(date)] noVNC listening on port 6080 (ultra-compressed)"
    break
  fi
  if [ $i -eq 10 ]; then
    echo "[ERROR] noVNC failed to bind on port 6080"
    exit 1
  fi
  sleep 1
done

# ============================================================================
# 6. TUNNEL – LOCALHOST.RUN (SSH, NO CLOUDFLARE - OPTIMIZED)
# ============================================================================
echo "[$(date)] Step 6: Starting SSH tunnel..."
pkill -f "localhost.run" || true
sleep 1

# Faster tunnel loop with aggressive reconnection
(
  while true; do
    ssh -o StrictHostKeyChecking=no -o ServerAliveInterval=20 \
      -o ServerAliveCountMax=3 \
      -o TCPKeepAliveInterval=20 \
      -R 80:localhost:6080 nokey@localhost.run \
      >> /tmp/tunnel.log 2>&1 &
    TUNNEL_PID=$!
    sleep 25
    if ! kill -0 $TUNNEL_PID 2>/dev/null; then
      sleep 2
    fi
  done
) &
TUNNEL_LOOP_PID=$!

# Wait for tunnel to establish and extract URL (faster)
echo "[$(date)] Waiting for tunnel URL..."
TUNNEL_URL=""
for i in {1..15}; do
  sleep 1
  TUNNEL_URL=$(grep -oE 'https://[a-zA-Z0-9-]+\.lhr\.life' /tmp/tunnel.log 2>/dev/null | tail -1)
  if [ -n "$TUNNEL_URL" ]; then
    echo "$TUNNEL_URL" > /tmp/tunnel_url.txt
    echo "[$(date)] Tunnel established: $TUNNEL_URL"
    break
  fi
done

if [ -z "$TUNNEL_URL" ]; then
  echo "[ERROR] Failed to establish tunnel URL within timeout"
  exit 1
fi

# ============================================================================
# 7. LIVE PREVIEW PANE (PORT 9090)
# ============================================================================
echo "[$(date)] Step 7: Starting live preview server..."

cat > /tmp/preview_server.py << 'PYTHON'
#!/usr/bin/env python3
import http.server
import socketserver
import os
from datetime import datetime
import time
import gzip
import io

PORT = 9090

class PreviewHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/' or self.path == '':
            self.send_response(200)
            self.send_header('Content-type', 'text/html; charset=utf-8')
            self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
            self.send_header('Content-Encoding', 'gzip')
            self.end_headers()
            
            tunnel_url = ""
            tunnel_file = "/tmp/tunnel_url.txt"
            
            if os.path.exists(tunnel_file):
                try:
                    with open(tunnel_file, 'r') as f:
                        tunnel_url = f.read().strip()
                except:
                    pass
            
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            if tunnel_url:
                # Ultra-aggressive noVNC compression parameters
                novnc_url = f"{tunnel_url}?quality=1&compression=9&autoconnect=true&reconnect=true&resize=scale&showDotCursor=true&view_mode=true"
                html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Chromium Desktop</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        body {{
            background: #000;
            font-family: system-ui, -apple-system, sans-serif;
            overflow: hidden;
        }}
        #container {{
            width: 100vw;
            height: 100vh;
            display: flex;
            flex-direction: column;
            position: fixed;
            top: 0;
            left: 0;
        }}
        #novnc {{
            flex: 1;
            border: none;
            width: 100%;
            height: calc(100vh - 32px);
            background: #000;
        }}
        #footer {{
            background: #0a0a0a;
            color: #666;
            padding: 8px 12px;
            font-size: 11px;
            border-top: 1px solid #222;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 32px;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
        }}
        #tunnel-info {{
            flex: 1;
            min-width: 0;
            overflow: hidden;
            text-overflow: ellipsis;
        }}
        .status {{
            color: #4a9eff;
            font-weight: bold;
        }}
        #timestamp {{
            flex-shrink: 0;
            margin-left: 10px;
        }}
    </style>
</head>
<body>
    <div id="container">
        <iframe id="novnc" src="{novnc_url}"></iframe>
        <div id="footer">
            <div id="tunnel-info">
                <span class="status">●</span> {tunnel_url}
            </div>
            <div id="timestamp">{timestamp}</div>
        </div>
    </div>
</body>
</html>"""
            else:
                html = """<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="refresh" content="3">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chromium Desktop</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        body {{
            background: #000;
            color: #888;
            font-family: system-ui, -apple-system, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            width: 100vw;
            overflow: hidden;
        }}
        .message {{
            text-align: center;
            padding: 20px;
        }}
        .spinner {{
            border: 3px solid #1a1a1a;
            border-top: 3px solid #4a9eff;
            border-radius: 50%;
            width: 32px;
            height: 32px;
            animation: spin 1s linear infinite;
            margin: 0 auto 15px;
        }}
        h1 {{
            font-size: 20px;
            margin-bottom: 8px;
            color: #aaa;
        }}
        p {{
            font-size: 12px;
        }}
        @keyframes spin {{
            0% {{ transform: rotate(0deg); }}
            100% {{ transform: rotate(360deg); }}
        }}
    </style>
</head>
<body>
    <div class="message">
        <div class="spinner"></div>
        <h1>Starting…</h1>
        <p>Tunnel initializing (3s refresh)</p>
    </div>
</body>
</html>"""
            
            html_bytes = html.encode('utf-8')
            
            # Gzip compress the HTML
            buf = io.BytesIO()
            with gzip.GzipFile(fileobj=buf, mode='wb') as f:
                f.write(html_bytes)
            compressed = buf.getvalue()
            
            self.wfile.write(compressed)
        else:
            self.send_response(404)
            self.end_headers()
    
    def log_message(self, format, *args):
        pass  # Suppress logging

try:
    with socketserver.TCPServer(("", PORT), PreviewHandler) as httpd:
        print(f"Preview server running on port {PORT}", flush=True)
        httpd.serve_forever()
except Exception as e:
    print(f"Preview server error: {e}", flush=True)
PYTHON

chmod +x /tmp/preview_server.py
python3 /tmp/preview_server.py > /dev/null 2>&1 &
PREVIEW_PID=$!

# Verify preview server is listening
for i in {1..10}; do
  if netstat -tuln 2>/dev/null | grep -q ':9090' || nc -z localhost 9090 2>/dev/null; then
    echo "[$(date)] Preview server listening on port 9090"
    break
  fi
  if [ $i -eq 10 ]; then
    echo "[ERROR] Preview server failed to start"
    exit 1
  fi
  sleep 1
done

# ============================================================================
# 8. SELF-HEALING WATCHDOG
# ============================================================================
echo "[$(date)] Step 8: Starting watchdog..."

cat > /tmp/watchdog.sh << 'WATCHDOG'
#!/bin/bash

WATCHDOG_LOG="/tmp/watchdog.log"
DISPLAY=:1
export DISPLAY
CHECK_COUNTER=0

# Restart functions with optimized flags
restart_xvfb() {
  Xvfb :1 -screen 0 1024x768x16 +iglx -nolisten unix > /dev/null 2>&1 &
}

restart_x11vnc() {
  x11vnc -display :1 -forever -nopw -rfbport 5900 -bg -shared -repeat \
    -8to24 -flashcmap -jpeg -quality 5 -fps 1 -wait 10 -defer 10 \
    -nomodtweak -noxdamage -noxfixes -noxext -fast -connect localhost \
    -threads -quiet > /dev/null 2>&1 &
}

restart_novnc() {
  novnc --listen 6080 --vnc localhost:5900 > /dev/null 2>&1 &
}

restart_chromium() {
  DISPLAY=:1 chromium-browser \
    --no-sandbox --disable-gpu --disable-gpu-compositing \
    --disable-extensions --disable-plugins \
    --start-fullscreen --no-first-run --disable-default-apps \
    --disable-sync --disable-translate \
    --user-data-dir=/home/runner/.chromium \
    --enable-smooth-scrolling \
    --renderer-process-limit=1 \
    --memory-pressure-off \
    --disable-background-networking \
    --disable-preconnect \
    --window-size=1024,768 \
    --no-first-run \
    --no-default-browser-check > /dev/null 2>&1 &
}

restart_tunnel() {
  ssh -o StrictHostKeyChecking=no -o ServerAliveInterval=30 \
    -R 80:localhost:6080 nokey@localhost.run >> /tmp/tunnel.log 2>&1 &
}

# Watchdog loop with tiered checking
while true; do
  CHECK_COUNTER=$((CHECK_COUNTER + 1))
  
  # CRITICAL checks every 3 seconds
  if ! pgrep Xvfb > /dev/null 2>&1; then
    echo "[$(date)] [Xvfb] DEAD - restarting..." >> $WATCHDOG_LOG
    restart_xvfb
  fi
  
  if ! nc -z localhost 5900 2>/dev/null; then
    echo "[$(date)] [x11vnc] Port 5900 down - restarting..." >> $WATCHDOG_LOG
    pkill -f "x11vnc" || true
    sleep 1
    restart_x11vnc
  fi
  
  if ! nc -z localhost 6080 2>/dev/null; then
    echo "[$(date)] [noVNC] Port 6080 down - restarting..." >> $WATCHDOG_LOG
    restart_novnc
  fi
  
  # Check SSH tunnel every 2 checks (6 seconds)
  if [ $((CHECK_COUNTER % 2)) -eq 0 ]; then
    if ! pgrep -f "localhost.run" > /dev/null 2>&1; then
      echo "[$(date)] [SSH Tunnel] DEAD - restarting..." >> $WATCHDOG_LOG
      pkill -f "localhost.run" || true
      sleep 1
      restart_tunnel &
      sleep 15
      TUNNEL_URL=$(grep -o 'https://[^ ]*\.lhr\.life' /tmp/tunnel.log 2>/dev/null | tail -1)
      if [ -n "$TUNNEL_URL" ]; then
        echo "$TUNNEL_URL" > /tmp/tunnel_url.txt
        echo "[$(date)] [SSH Tunnel] New URL: $TUNNEL_URL" >> $WATCHDOG_LOG
      fi
    fi
  fi
  
  # Check Chromium every 3 checks (9 seconds)
  if [ $((CHECK_COUNTER % 3)) -eq 0 ]; then
    if ! pgrep chromium > /dev/null 2>&1; then
      echo "[$(date)] [Chromium] DEAD - restarting..." >> $WATCHDOG_LOG
      restart_chromium
    fi
  fi
  
  # Check Fluxbox every 4 checks (12 seconds)
  if [ $((CHECK_COUNTER % 4)) -eq 0 ]; then
    if ! pgrep fluxbox > /dev/null 2>&1; then
      echo "[$(date)] [Fluxbox] DEAD - restarting..." >> $WATCHDOG_LOG
      fluxbox > /dev/null 2>&1 &
      sleep 1
      fluxbox-remote "SetStyle: Clean" > /dev/null 2>&1
    fi
  fi
  
  sleep 3
done
WATCHDOG

chmod +x /tmp/watchdog.sh
/tmp/watchdog.sh > /dev/null 2>&1 &
WATCHDOG_PID=$!

echo "[$(date)] Watchdog started"

# ============================================================================
# 9. FINAL STARTUP VERIFICATION
# ============================================================================
echo "[$(date)] Step 9: Final startup verification..."

verify_component() {
  local name=$1
  local check=$2
  local retries=3
  
  for i in $(seq 1 $retries); do
    if eval "$check" > /dev/null 2>&1; then
      echo "[$(date)] ✓ $name verified"
      return 0
    fi
    if [ $i -lt $retries ]; then
      echo "[$(date)] $name check failed, retry $i/$retries..."
      sleep 10
    fi
  done
  
  echo "[ERROR] $name verification failed after $retries retries"
  return 1
}

verify_component "Xvfb" "pgrep Xvfb"
verify_component "Fluxbox" "pgrep fluxbox"
verify_component "x11vnc (port 5900)" "netstat -tuln 2>/dev/null | grep -q ':5900' || nc -z localhost 5900 2>/dev/null"
verify_component "noVNC (port 6080)" "netstat -tuln 2>/dev/null | grep -q ':6080' || nc -z localhost 6080 2>/dev/null"
verify_component "Chromium" "pgrep chromium"
verify_component "SSH Tunnel" "pgrep -f 'localhost.run'"
verify_component "Preview Server (port 9090)" "netstat -tuln 2>/dev/null | grep -q ':9090' || nc -z localhost 9090 2>/dev/null"

echo ""
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║                   ALL SYSTEMS READY                           ║"
echo "║           (Optimized for Low-Bandwidth Networks)              ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

TUNNEL_URL=$(cat /tmp/tunnel_url.txt 2>/dev/null)
if [ -n "$TUNNEL_URL" ]; then
  echo "📱 Remote Desktop URL: $TUNNEL_URL"
  echo "🌐 Live Preview:       http://localhost:9090"
  echo ""
  echo "⚡ Optimizations Active:"
  echo "  ✓ 1 FPS adaptive rendering"
  echo "  ✓ JPEG quality 5 (extreme compression)"
  echo "  ✓ 16-bit color depth"
  echo "  ✓ Keyboard priority input"
  echo "  ✓ Aggressive socket tuning"
  echo "  ✓ Tiered watchdog (faster repairs)"
  echo ""
  echo "🛠️ Components:"
  echo "  ✓ Xvfb (Virtual Display - 16-bit)"
  echo "  ✓ Fluxbox (Desktop - minimal)"
  echo "  ✓ Chromium (Browser - lite mode)"
  echo "  ✓ x11vnc (VNC Server - 8-bit indexed)"
  echo "  ✓ noVNC (Web Interface - gzip)"
  echo "  ✓ SSH Tunnel (localhost.run - TCPKeepAlive)"
  echo "  ✓ Watchdog (Self-Healing - tiered checks)"
  echo ""
fi

echo "[$(date)] Startup complete" >> /tmp/watchdog.log

# ============================================================================
# 10. KEEPALIVE & CRASH RECOVERY
# ============================================================================
# Stay alive forever
while true; do
  sleep 60
done
