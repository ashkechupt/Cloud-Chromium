# Project Overview

An optimized Chromium desktop environment running inside Replit via VNC + noVNC, tunneled through localhost.run for remote access.

## User Preferences

- Keep the original `zipFile.zip` intact
- Scripts should be modular and separated into individual files

## File Structure

| File | Purpose |
|------|---------|
| `main.sh` | Main orchestrator script |
| `fluxbox_startup.sh` | Fluxbox startup with Chromium auto-launch |
| `watchdog.sh` | Self-healing watchdog (tiered checking) |
| `preview_server.py` | Python HTTP server on port 9090 |
| `OPTIMIZATIONS.md` | Performance tuning documentation |
| `zipFile.zip` | Original imported archive (preserved) |

## How to Run

Click the Run button in Replit. The script will:
1. Download and install `websockify` + `noVNC` files
2. Start Xvfb virtual display with Fluxbox
3. Launch Chromium with 60+ performance flags
4. Start x11vnc (VNC server) on port 5900
5. Start websockify bridging VNC to WebSocket on port 6080
6. Open SSH tunnel to localhost.run for remote access
7. Start preview server on port 9090
8. Start self-healing watchdog
