#!/bin/bash

WATCHDOG_LOG="/tmp/watchdog.log"
DISPLAY=:1
export DISPLAY
CHECK_COUNTER=0

# Find Xvfb (cached path)
XVFB_BIN="/nix/store/sx3d9r61bi7xpg1vjiyvbay99634i282-xorg-server-21.1.18/bin/Xvfb"
if [ ! -f "$XVFB_BIN" ]; then
    XVFB_BIN=$(grep -o '/nix/store/[^"'"'"']*/xorg-server-[^/]*/bin/Xvfb' $(which xvfb-run) 2>/dev/null | head -1)
fi

# Restart functions with optimized flags
restart_xvfb() {
  $XVFB_BIN :1 -screen 0 1024x768x16 +iglx -nolisten unix > /dev/null 2>&1 &
}

restart_x11vnc() {
  x11vnc -display :1 -forever -nopw -rfbport 5900 \
    -shared -repeat \
    -flashcmap -8to24 \
    > /tmp/x11vnc.log 2>&1 &
}

restart_websockify() {
  PYTHONPATH=/tmp/websockify-0.10.0 python3 -m websockify --web /tmp/novnc localhost:6080 localhost:5900 > /dev/null 2>&1 &
}

restart_chromium() {
  DISPLAY=:1 chromium-browser \
    --no-sandbox --disable-gpu --disable-gpu-compositing \
    --disable-extensions --disable-plugins \
    --start-fullscreen --no-first-run --disable-default-apps \
    --disable-sync --disable-translate \
    --user-data-dir=/home/runner/.chromium \
    --enable-smooth-scrolling \
    --renderer-process-limit=1 \
    --memory-pressure-off \
    --disable-background-networking \
    --disable-preconnect \
    --window-size=1024,768 \
    --no-first-run \
    --no-default-browser-check > /dev/null 2>&1 &
}

restart_tunnel() {
  ssh -o StrictHostKeyChecking=no -o ServerAliveInterval=30 \
    -R 80:localhost:6080 nokey@localhost.run >> /tmp/tunnel.log 2>&1 &
}

# Watchdog loop with tiered checking
while true; do
  CHECK_COUNTER=$((CHECK_COUNTER + 1))

  # CRITICAL checks every 3 seconds
  if ! pgrep -f Xvfb > /dev/null 2>&1; then
    echo "[$(date)] [Xvfb] DEAD - restarting..." >> $WATCHDOG_LOG
    restart_xvfb
  fi

  if ! nc -z localhost 5900 2>/dev/null; then
    echo "[$(date)] [x11vnc] Port 5900 down - restarting..." >> $WATCHDOG_LOG
    pkill -f "x11vnc" || true
    sleep 1
    restart_x11vnc
  fi

  if ! nc -z localhost 6080 2>/dev/null; then
    echo "[$(date)] [websockify] Port 6080 down - restarting..." >> $WATCHDOG_LOG
    restart_websockify
  fi

  # Check SSH tunnel every 2 checks (6 seconds)
  if [ $((CHECK_COUNTER % 2)) -eq 0 ]; then
    if ! pgrep -f "localhost.run" > /dev/null 2>&1; then
      echo "[$(date)] [SSH Tunnel] DEAD - restarting..." >> $WATCHDOG_LOG
      pkill -f "localhost.run" || true
      sleep 1
      restart_tunnel &
      sleep 15
      TUNNEL_URL=$(grep -o 'https://[^ ]*\.lhr\.life' /tmp/tunnel.log 2>/dev/null | tail -1)
      if [ -n "$TUNNEL_URL" ]; then
        echo "$TUNNEL_URL" > /tmp/tunnel_url.txt
        echo "[$(date)] [SSH Tunnel] New URL: $TUNNEL_URL" >> $WATCHDOG_LOG
      fi
    fi
  fi

  # Check Chromium every 3 checks (9 seconds)
  if [ $((CHECK_COUNTER % 3)) -eq 0 ]; then
    if ! pgrep chromium > /dev/null 2>&1; then
      echo "[$(date)] [Chromium] DEAD - restarting..." >> $WATCHDOG_LOG
      restart_chromium
    fi
  fi

  # Check Fluxbox every 4 checks (12 seconds)
  if [ $((CHECK_COUNTER % 4)) -eq 0 ]; then
    if ! pgrep fluxbox > /dev/null 2>&1; then
      echo "[$(date)] [Fluxbox] DEAD - restarting..." >> $WATCHDOG_LOG
      fluxbox > /dev/null 2>&1 &
      sleep 1
      fluxbox-remote "SetStyle: Clean" > /dev/null 2>&1
    fi
  fi

  sleep 3
done
