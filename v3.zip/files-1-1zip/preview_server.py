#!/usr/bin/env python3
import http.server
import socketserver
import os
from datetime import datetime
import time
import gzip
import io

PORT = 9090

class PreviewHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/' or self.path == '':
            self.send_response(200)
            self.send_header('Content-type', 'text/html; charset=utf-8')
            self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
            self.send_header('Content-Encoding', 'gzip')
            self.end_headers()

            tunnel_url = ""
            tunnel_file = "/tmp/tunnel_url.txt"

            if os.path.exists(tunnel_file):
                try:
                    with open(tunnel_file, 'r') as f:
                        tunnel_url = f.read().strip()
                except:
                    pass

            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            if tunnel_url:
                # Ultra-aggressive noVNC compression parameters
                novnc_url = f"{tunnel_url}?quality=1&compression=9&autoconnect=true&reconnect=true&resize=scale&showDotCursor=true&view_mode=true"
                html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Chromium Desktop</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        body {{
            background: #000;
            font-family: system-ui, -apple-system, sans-serif;
            overflow: hidden;
        }}
        #container {{
            width: 100vw;
            height: 100vh;
            display: flex;
            flex-direction: column;
            position: fixed;
            top: 0;
            left: 0;
        }}
        #novnc {{
            flex: 1;
            border: none;
            width: 100%;
            height: calc(100vh - 32px);
            background: #000;
        }}
        #footer {{
            background: #0a0a0a;
            color: #666;
            padding: 8px 12px;
            font-size: 11px;
            border-top: 1px solid #222;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 32px;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
        }}
        #tunnel-info {{
            flex: 1;
            min-width: 0;
            overflow: hidden;
            text-overflow: ellipsis;
        }}
        .status {{
            color: #4a9eff;
            font-weight: bold;
        }}
        #timestamp {{
            flex-shrink: 0;
            margin-left: 10px;
        }}
    </style>
</head>
<body>
    <div id="container">
        <iframe id="novnc" src="{novnc_url}"></iframe>
        <div id="footer">
            <div id="tunnel-info">
                <span class="status">&#9679;</span> {tunnel_url}
            </div>
            <div id="timestamp">{timestamp}</div>
        </div>
    </div>
</body>
</html>"""
            else:
                html = """<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="refresh" content="3">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chromium Desktop</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            background: #000;
            color: #888;
            font-family: system-ui, -apple-system, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            width: 100vw;
            overflow: hidden;
        }
        .message {
            text-align: center;
            padding: 20px;
        }
        .spinner {
            border: 3px solid #1a1a1a;
            border-top: 3px solid #4a9eff;
            border-radius: 50%;
            width: 32px;
            height: 32px;
            animation: spin 1s linear infinite;
            margin: 0 auto 15px;
        }
        h1 {
            font-size: 20px;
            margin-bottom: 8px;
            color: #aaa;
        }
        p {
            font-size: 12px;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="message">
        <div class="spinner"></div>
        <h1>Starting...</h1>
        <p>Tunnel initializing (3s refresh)</p>
    </div>
</body>
</html>"""

            html_bytes = html.encode('utf-8')

            # Gzip compress the HTML
            buf = io.BytesIO()
            with gzip.GzipFile(fileobj=buf, mode='wb') as f:
                f.write(html_bytes)
            compressed = buf.getvalue()

            self.wfile.write(compressed)
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, format, *args):
        pass  # Suppress logging

try:
    with socketserver.TCPServer(("", PORT), PreviewHandler) as httpd:
        print(f"Preview server running on port {PORT}", flush=True)
        httpd.serve_forever()
except Exception as e:
    print(f"Preview server error: {e}", flush=True)
