#!/bin/bash
# NOTE: No set -e because Replit container has read-only /proc and /etc
# We handle errors explicitly for each step

# ============================================================================
# START PREVIEW SERVER IMMEDIATELY (so workflow sees port 9090)
# ============================================================================
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cp "$SCRIPT_DIR/preview_server.py" /tmp/preview_server.py
chmod +x /tmp/preview_server.py
python3 /tmp/preview_server.py > /dev/null 2>&1 &
PREVIEW_PID=$!

# Trap to clean up on exit
trap 'echo "Script terminated at $(date)" >> /tmp/watchdog.log; kill 0' EXIT HUP INT TERM

echo "[$(date)] Starting Optimized Replit Chromium Desktop..."

# ============================================================================
# 0. DOWNLOAD WEBSOCKIFY & NOVNC (Replit Nix environment - no apt-get)
# ============================================================================
echo "[$(date)] Step 0: Setting up websockify and noVNC..."

# Download websockify if not present (run directly from source, no install needed)
if [ ! -d "/tmp/websockify-0.10.0" ]; then
    curl -sL "https://files.pythonhosted.org/packages/source/w/websockify/websockify-0.10.0.tar.gz" | tar xz -C /tmp
    echo "[$(date)] websockify source downloaded"
else
    echo "[$(date)] websockify source already available"
fi
# Set PYTHONPATH so python3 -m websockify works
export PYTHONPATH=/tmp/websockify-0.10.0:$PYTHONPATH

# Download noVNC HTML files if not present
if [ ! -f "/tmp/novnc/vnc.html" ]; then
    mkdir -p /tmp/novnc
    if [ ! -f "/tmp/novnc.zip" ]; then
        curl -sL "https://github.com/novnc/noVNC/archive/refs/tags/v1.4.0.zip" -o /tmp/novnc.zip
    fi
    unzip -q -o /tmp/novnc.zip -d /tmp/novnc_extracted || true
    cp -r /tmp/novnc_extracted/noVNC-1.4.0/* /tmp/novnc/ 2>/dev/null || true
    echo "[$(date)] noVNC files downloaded"
else
    echo "[$(date)] noVNC files already available"
fi

# Find Xvfb path from nix store (cached from xvfb-run dependency)
XVFB_BIN="/nix/store/sx3d9r61bi7xpg1vjiyvbay99634i282-xorg-server-21.1.18/bin/Xvfb"
if [ ! -f "$XVFB_BIN" ]; then
    XVFB_BIN=$(grep -o '/nix/store/[^"'"'"']*/xorg-server-[^/]*/bin/Xvfb' $(which xvfb-run) 2>/dev/null | head -1)
fi
if [ -z "$XVFB_BIN" ] || [ ! -f "$XVFB_BIN" ]; then
    echo "[ERROR] Xvfb not found"
    exit 1
fi
echo "[$(date)] Xvfb found at: $XVFB_BIN"

# ============================================================================
# 1. BASE SETUP + PERFORMANCE TUNING
# ============================================================================
echo "[$(date)] Step 1: Base setup & optimization..."

# Kernel tuning for network performance (best effort, container may be read-only)
(echo 1 > /proc/sys/net/ipv4/tcp_tw_reuse) 2>/dev/null || true
(echo 1 > /proc/sys/net/ipv4/tcp_timestamps) 2>/dev/null || true
sysctl -w net.ipv4.tcp_window_scaling=1 2>/dev/null || true
sysctl -w net.core.rmem_max=134217728 2>/dev/null || true

# Create Chromium policies directory and file (best effort, container may be read-only)
(mkdir -p /etc/chromium/policies/managed && cat > /etc/chromium/policies/managed/policies.json << 'EOF'
{"ExtensionInstallAllowlist": ["*"]}
EOF
) 2>/dev/null || true

# Initialize logs
> /tmp/watchdog.log
> /tmp/tunnel.log

# Disable swap (RAM only, faster)
swapoff -a 2>/dev/null || true

echo "[$(date)] Base setup complete - Network tuned"

# ============================================================================
# 2. VIRTUAL DISPLAY & DESKTOP (OPTIMIZED)
# ============================================================================
echo "[$(date)] Step 2: Starting virtual display..."
# 1366x768 at 24-bit color depth, DPR=1
$XVFB_BIN :1 -screen 0 1366x768x24 +iglx -nolisten unix -dpi 96 > /dev/null 2>&1 &
XVFB_PID=$!
sleep 1

# Set display for all subsequent commands
export DISPLAY=:1

# Disable cursor acceleration entirely (1 = linear, 0 threshold = never accelerates)
xset m 1 0
xset r rate 150 40   # Keyboard repeat: delay 150ms, rate 40 Hz (faster)
xset s off           # Disable screen saver
xset -dpms 2>/dev/null || true  # Disable power management (not always supported in Xvfb)

# Write Fluxbox config BEFORE starting it so the rules are picked up
mkdir -p ~/.fluxbox/styles

# Zero-height title bar theme — eliminates ALL window decoration overhead
cat > ~/.fluxbox/styles/notitlebar << 'EOF'
*.font:                 fixed-8
*.titleHeight:          0
*.handleWidth:          0
*.bevelWidth:           0
*.borderWidth:          0
*.borderColor:          #000000
toolbar.height:         0
toolbar.borderWidth:    0
menu.borderWidth:       0
menu.bevelWidth:        0
EOF

# Full init: disable toolbar, slit, reference zero-height style
cat > ~/.fluxbox/init << 'EOF'
session.screen0.toolbar.visible: false
session.screen0.toolbar.widthPercent: 0
session.screen0.slit.placement: BottomRight
session.screen0.slit.autoHide: true
session.screen0.workspaces: 1
session.screen0.workspaceNames: Desktop
session.screen0.styleFile: /root/.fluxbox/styles/notitlebar
session.screen0.tabs.intitlebar: false
EOF

# Apps: every window gets no decoration and sits at 0,0 covering the full display
cat > ~/.fluxbox/apps << 'EOF'
[app] (class=Chromium-browser)
  [Deco]        {NONE}
  [Dimensions]  {1366 768}
  [Position]    (UPPERLEFT) {0 0}
[end]
[app] (class=chromium)
  [Deco]        {NONE}
  [Dimensions]  {1366 768}
  [Position]    (UPPERLEFT) {0 0}
[end]
[app] (class=Chromium)
  [Deco]        {NONE}
  [Dimensions]  {1366 768}
  [Position]    (UPPERLEFT) {0 0}
[end]
EOF

# Start Fluxbox — it will now read the above configs on launch
fluxbox > /dev/null 2>&1 &
sleep 2

echo "[$(date)] Virtual display ready - 16-bit optimized"

# ============================================================================
# 3. FLUXBOX STARTUP SCRIPT WITH CHROMIUM AUTO-START (OPTIMIZED)
# ============================================================================
echo "[$(date)] Step 3: Setting up Fluxbox startup with optimized Chromium..."
mkdir -p ~/.fluxbox
cp "$SCRIPT_DIR/fluxbox_startup.sh" ~/.fluxbox/startup
chmod +x ~/.fluxbox/startup

# Manual Chromium startup
(
  sleep 3
  chromium-browser \
    --no-sandbox \
    --disable-setuid-sandbox \
    --disable-seccomp-sandbox \
    --disable-dev-shm-usage \
    --disable-gpu --disable-gpu-compositing \
    --no-first-run --no-default-browser-check \
    --disable-sync --disable-translate \
    --user-data-dir=$HOME/.chromium \
    --enable-smooth-scrolling \
    --enable-features=ScrollUnification \
    --renderer-process-limit=4 \
    --memory-pressure-off \
    --disk-cache-size=268435456 \
    --media-cache-size=134217728 \
    --disable-hang-monitor \
    --disable-prompt-on-repost \
    --disable-default-apps \
    --disable-component-update \
    --disable-breakpad \
    --disable-domain-reliability \
    --disable-infobars \
    --disable-session-crashed-bubble \
    --disable-safe-browsing \
    --window-size=1366,768 \
    --window-position=0,0 \
    --force-device-scale-factor=1 \
    --high-dpi-support=1 \
    --disable-low-res-tiling > /dev/null 2>&1 &

  # Once Chromium appears, force it flush to top-left with no decorations
  sleep 6
  for attempt in 1 2 3; do
    WID=$(xdotool search --sync --class chromium 2>/dev/null | tail -1)
    [ -n "$WID" ] && break
    sleep 2
  done
  if [ -n "$WID" ]; then
    xdotool windowmove --sync "$WID" 0 0
    xdotool windowsize --sync "$WID" 1366 768
  fi
) &

echo "[$(date)] Chromium auto-start configured - Performance optimized"

# ============================================================================
# 4. X11VNC -- ULTRA-LOW BANDWIDTH (EXTREME OPTIMIZATION)
# ============================================================================
echo "[$(date)] Step 4: Starting x11vnc..."
# Kill any leftover instances
pkill -f "x11vnc" || true
sleep 1

# x11vnc: minimum latency (1ms poll+defer), LAN speed, no cursor accel override
x11vnc -display :1 -forever -nopw -rfbport 5900 \
  -shared -repeat \
  -wait 1 \
  -defer 1 \
  -speeds lan \
  -noxdamage \
  > /tmp/x11vnc.log 2>&1 &

# Verify port 5900 is listening
for i in {1..10}; do
  if netstat -tuln 2>/dev/null | grep -q ':5900' || nc -z localhost 5900 2>/dev/null; then
    echo "[$(date)] x11vnc listening on port 5900 (1 FPS, 8-bit)"
    break
  fi
  if [ $i -eq 10 ]; then
    echo "[WARN] x11vnc may not be ready, continuing..."
    break
  fi
  sleep 1
done

# ============================================================================
# 5. WEBSOCKIFY + NOVNC (OPTIMIZED)
# ============================================================================
echo "[$(date)] Step 5: Starting websockify (noVNC bridge)..."

PYTHONPATH=/tmp/websockify-0.10.0 python3 -m websockify --web /tmp/novnc localhost:6080 localhost:5900 > /dev/null 2>&1 &
NOVNC_PID=$!

# Verify port 6080 is listening
for i in {1..10}; do
  if netstat -tuln 2>/dev/null | grep -q ':6080' || nc -z localhost 6080 2>/dev/null; then
    echo "[$(date)] websockify/noVNC listening on port 6080"
    break
  fi
  if [ $i -eq 10 ]; then
    echo "[WARN] websockify may not be ready, continuing..."
    break
  fi
  sleep 1
done

# ============================================================================
# 6. TUNNEL -- LOCALHOST.RUN (SSH, NO CLOUDFLARE - OPTIMIZED)
# ============================================================================
echo "[$(date)] Step 6: Starting SSH tunnel..."
pkill -f "localhost.run" || true
sleep 1

# Tunnel loop with localhost.run
(
  while true; do
    ssh -o StrictHostKeyChecking=no -o ServerAliveInterval=20 \
      -o ServerAliveCountMax=3 \
      -R 80:localhost:6080 nokey@localhost.run \
      >> /tmp/tunnel.log 2>&1 &
    TUNNEL_PID=$!
    sleep 30
    if ! kill -0 $TUNNEL_PID 2>/dev/null; then
      sleep 5
    fi
  done
) &
TUNNEL_LOOP_PID=$!

# Wait for tunnel to establish and extract URL
echo "[$(date)] Waiting for tunnel URL..."
TUNNEL_URL=""
for i in {1..20}; do
  sleep 2
  TUNNEL_URL=$(grep -oE 'https://[a-zA-Z0-9-]+\.(lhr\.life|localhost\.run)' /tmp/tunnel.log 2>/dev/null | tail -1)
  if [ -n "$TUNNEL_URL" ]; then
    echo "$TUNNEL_URL" > /tmp/tunnel_url.txt
    echo "[$(date)] Tunnel established: $TUNNEL_URL"
    break
  fi
done

if [ -z "$TUNNEL_URL" ]; then
  echo "[WARN] Tunnel URL not found yet, continuing anyway..."
  echo "       Check /tmp/tunnel.log for details."
fi

# ============================================================================
# 7. WATCHDOG (already running preview server from top of script)
# ============================================================================
echo "[$(date)] Step 7: Starting watchdog..."

cp "$SCRIPT_DIR/watchdog.sh" /tmp/watchdog.sh
chmod +x /tmp/watchdog.sh
/tmp/watchdog.sh > /dev/null 2>&1 &
WATCHDOG_PID=$!

echo "[$(date)] Watchdog started"

# ============================================================================
# 8. FINAL STARTUP VERIFICATION
# ============================================================================
echo "[$(date)] Step 8: Final startup verification..."

verify_component() {
  local name=$1
  local check=$2
  local retries=3

  for i in $(seq 1 $retries); do
    if eval "$check" > /dev/null 2>&1; then
      echo "[$(date)] ✓ $name verified"
      return 0
    fi
    if [ $i -lt $retries ]; then
      echo "[$(date)] $name check failed, retry $i/$retries..."
      sleep 10
    fi
  done

  echo "[WARN] $name verification failed after $retries retries"
  return 1
}

verify_component "Xvfb" "pgrep -f Xvfb"
verify_component "Fluxbox" "pgrep fluxbox"
verify_component "x11vnc (port 5900)" "netstat -tuln 2>/dev/null | grep -q ':5900' || nc -z localhost 5900 2>/dev/null"
verify_component "websockify (port 6080)" "netstat -tuln 2>/dev/null | grep -q ':6080' || nc -z localhost 6080 2>/dev/null"
verify_component "Chromium" "pgrep chromium"
verify_component "SSH Tunnel" "pgrep -f 'localhost.run'"
verify_component "Preview Server (port 9090)" "netstat -tuln 2>/dev/null | grep -q ':9090' || nc -z localhost 9090 2>/dev/null"

echo ""
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║                   ALL SYSTEMS READY                           ║"
echo "║           (Optimized for Low-Bandwidth Networks)              ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

TUNNEL_URL=$(cat /tmp/tunnel_url.txt 2>/dev/null)
if [ -n "$TUNNEL_URL" ]; then
  echo "📱 Remote Desktop URL: $TUNNEL_URL"
  echo "🌐 Live Preview:       http://localhost:9090"
  echo ""
  echo "⚡ Optimizations Active:"
  echo "  ✓ 1366x768 @ 24-bit / DPR=1"
  echo "  ✓ 5ms poll latency (ultra-fast clicks)"
  echo "  ✓ LAN-speed x11vnc encoding"
  echo "  ✓ Keyboard repeat 150ms/40Hz"
  echo "  ✓ Screen saver + DPMS disabled"
  echo "  ✓ Tiered watchdog (faster repairs)"
  echo ""
  echo "🛠️ Components:"
  echo "  ✓ Xvfb (Virtual Display - 1366x768x24)"
  echo "  ✓ Fluxbox (Desktop - minimal)"
  echo "  ✓ Chromium (Browser - lite mode)"
  echo "  ✓ x11vnc (VNC Server - 5ms defer/wait)"
  echo "  ✓ websockify (WebSocket bridge)"
  echo "  ✓ noVNC (Web Interface)"
  echo "  ✓ SSH Tunnel (localhost.run - TCPKeepAlive)"
  echo "  ✓ Watchdog (Self-Healing - tiered checks)"
  echo ""
fi

echo "[$(date)] Startup complete" >> /tmp/watchdog.log

# ============================================================================
# 9. KEEPALIVE & CRASH RECOVERY
# ============================================================================
# Stay alive forever
while true; do
  sleep 60
done
