{pkgs}: {
  deps = [
    pkgs.nettools
    pkgs.curl
    pkgs.xdotool
    pkgs.wmctrl
    pkgs.xorg.xset
    pkgs.procps
    pkgs.python3
    pkgs.netcat
    pkgs.openssh
    pkgs.chromium
    pkgs.x11vnc
    pkgs.fluxbox
    pkgs.xvfb-run
    pkgs.unzip
  ];
}
