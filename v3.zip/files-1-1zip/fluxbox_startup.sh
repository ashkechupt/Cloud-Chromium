#!/bin/bash
exec dbus-launch --exit-with-session fluxbox

# Chromium with extensions enabled, networking fully on, fast page loads
chromium-browser \
  --no-sandbox \
  --disable-setuid-sandbox \
  --disable-seccomp-sandbox \
  --disable-dev-shm-usage \
  --disable-gpu --disable-gpu-compositing \
  --no-first-run --no-default-browser-check \
  --disable-sync --disable-translate \
  --user-data-dir=$HOME/.chromium \
  --enable-smooth-scrolling \
  --enable-features=ScrollUnification \
  --renderer-process-limit=4 \
  --memory-pressure-off \
  --disk-cache-size=268435456 \
  --media-cache-size=134217728 \
  --disable-hang-monitor \
  --disable-prompt-on-repost \
  --disable-default-apps \
  --disable-component-update \
  --disable-breakpad \
  --disable-domain-reliability \
  --disable-infobars \
  --disable-session-crashed-bubble \
  --disable-safe-browsing \
  --disable-notifications \
  --disable-print-preview \
  --disable-geolocation \
  --disable-webgl \
  --disable-webnfc \
  --disable-webusb \
  --window-size=1366,750 \
  --force-device-scale-factor=1 \
  --high-dpi-support=1 \
  --disable-low-res-tiling \
  --no-pings \
  --no-service-autorun > /dev/null 2>&1 &
